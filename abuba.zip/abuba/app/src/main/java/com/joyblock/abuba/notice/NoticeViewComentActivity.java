package com.joyblock.abuba.notice;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.joyblock.abuba.R;

public class NoticeViewComentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_view_coment);
    }
}
