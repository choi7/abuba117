package com.joyblock.abuba.notice;

import android.graphics.drawable.Drawable;

public class NoticeListViewItem {

    private Drawable photo ;
    private String title,count,name;
    boolean a=false;

    public NoticeListViewItem(Drawable photo,String title,String count,String name){
        this.photo=photo;
        this.title=title;
        this.count=count;
        this.name=name;
    }

    public Drawable getPhoto(){
        return photo;
    }
    public String getTitle(){
        return title;
    }
    public String getCount(){
        return count;
    }
    public String getName(){
        return name;
    }


//    public Drawable getIcon() {
//        return this.iconDrawable ;
//    }
//    public String getTitle() {
//        return this.titleStr ;
//    }
//    public Drawable getIcon1() {
//        return this.iconDrawable1 ;
//    }

}