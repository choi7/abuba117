package com.joyblock.abuba.notice;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;

import com.joyblock.abuba.R;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;


/**
 * Created by hyoshinchoi on 2018. 1. 10..
 */

public class FragmentNotice extends android.support.v4.app.Fragment {


    SharedPreferences pref;
    String seq_user,seq_kindergarden,seq_kindergarden_class;
    NoticeListViewAdapter adapter;
    ListView listView;
    public FragmentNotice() {


    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


//        seq_user = pref.getString("seq_user","dd");
//        Log.d("seq_user : ", seq_user);


    }

    /*
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }
    */




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_notice_notice, container, false);

        adapter = new NoticeListViewAdapter();

        listView = rootView.findViewById(R.id.noticeListView);

        listView.setAdapter(adapter);

        for(int i=0;i<4;i++ ){
            adapter.addItem(getResources().getDrawable(R.mipmap.ic_document), "11","11","11");
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

//                Toast.makeText(MainDawerSelectActivity.this, mData.mTitle,Toast.LENGTH_LONG).show();

                Intent intent = new Intent(getContext(), NoticeDetailActivity.class);
                intent.putExtra("seq_notice",position);
                intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);

                startActivity(intent);

//                switch (position) {
//                    case 0 :
////                        Toast.makeText(getApplicationContext(),list[position],list[position].length()).show();
//                        Intent intent = new Intent(getContext(), NoticeDetailActivity.class);
////                        intent.putExtra("type", "recent");
//                        intent.putExtra("position", position);
//                        System.out.println("position : "+intent.getIntExtra("position",-1));
//
////                        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
//                        startActivity(intent);
////                        startActivity(new Intent(NoticeActivity.this.getApplicationContext(), NoticeDetailActivity.class));
//                        break;
//                    case 1 :
////                        getApplicationContext().startActivity(new Intent(getApplicationContext(), MedicineActivity.class));
//                            Intent intent1 = new Intent(getContext(), NoticeDetailActivity.class);
//                            intent1.putExtra("position", position);
//                            System.out.println("position : "+intent1.getIntExtra("position",-1));
//                        break;
////                    case 2 :
////                        getApplicationContext().startActivity(new Intent(getApplicationContext(), HomeCommingActivity.class));
////                        break;
////                    case 3 :
////                        getApplicationContext().startActivity(new Intent(getApplicationContext(), AttendanceActivity.class));
////                        break;
//                        /*
//                    case "알림" :
//                        Intent s4 = new Intent(MainDawerSelectActivity.this, NoticeActivity.class);
//                        MainDawerSelectActivity.this.startActivity(s4);
//                        break;
//
//                    case "사진 앨범" :
//                        Intent s6 = new Intent(MainDawerSelectActivity.this, PhotoActivity.class);
//                        MainDawerSelectActivity.this.startActivity(s6);
//                        break;
//                        */
//
//                }

            }
        });
        adapter.notifyDataSetChanged();

        return rootView;


//        return inflater.inflate(R.layout.noticelistviewcustom, container, false);


    }

    public class BuyTask extends AsyncTask<Void, Void, String> {
        OkHttpClient client;
        okhttp3.Request request;
        RequestBody formBody;

        public BuyTask(String seq_user, String seq_kindergarden, String is_reply, String seq_kindergarden_class, String title, String content, String files) {
            client = new OkHttpClient();
            formBody = new FormBody.Builder()
                    .add("seq_user", seq_user)
                    .add("seq_kindergarden", seq_kindergarden)
                    .add("is_reply", is_reply)
                    .add("seq_kindergarden_class", seq_kindergarden_class)
                    .add("title", title)
                    .add("content", content)
                    .add("files", files)
//                    .add("cu_num", cu_num + "")
                    .build();

            request = new okhttp3.Request.Builder()
                    .url("http://58.229.208.246/Ububa/insertNotice.do")
                    .post(formBody)
                    .build();
        }


        @Override
        protected String doInBackground(Void... params) {
            try {
                okhttp3.Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    return null;
                }
                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String json) {
            super.onPostExecute(json);
            Log.d("TAG", json);
            try {
                JSONObject jsonResponse = new JSONObject(json);
                System.out.println("반환되는 값 : " + jsonResponse);
                Integer ss = Integer.parseInt(jsonResponse.getString("resultCode"));
                System.out.println(ss);

                if (ss == 200) {
                    String userID = jsonResponse.getString("resultCode");
                    String userPassword = jsonResponse.getString("resultMsg");
                    System.out.println(userID + userPassword);
                    JSONObject json1 = new JSONObject(jsonResponse.getString("retMap"));
                    System.out.println(json1);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
    }


}
