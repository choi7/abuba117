package com.joyblock.abuba;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

public class DocumentSelectActivity extends AppCompatActivity {

    String[] documentSelectList = {"교육계획안", "투약의뢰서", "귀가동의서", "출석부"};
    ListView listView;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document_select);


        listView = (ListView) findViewById(R.id.documentSelectListView);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, documentSelectList);
        listView.setAdapter(adapter);




    }
}
