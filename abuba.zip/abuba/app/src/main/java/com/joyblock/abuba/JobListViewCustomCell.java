package com.joyblock.abuba;

import android.graphics.drawable.Drawable;

/**
 * Created by hyoshinchoi on 2018. 1. 11..
 */

public class JobListViewCustomCell {

    public String mTitle;

}
