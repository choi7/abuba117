package com.joyblock.abuba;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

public abstract class BaseActivity extends AppCompatActivity {
    RelativeLayout.LayoutParams rp;
    LinearLayout.LayoutParams lp;
    int width, height;
    public SharedPreferences pref;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 버전별로 상태바 배경 색상 변경
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#33CCCC"));
        } if (Build.VERSION.SDK_INT >= 23) {
            getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        }

        Display display = getWindowManager().getDefaultDisplay();
        Point size = new Point();
        display.getSize(size);
        width = size.x;
        height = size.y;

//        rp.width = cp(90);

        pref = getSharedPreferences("pref", MODE_PRIVATE);
    }

    RelativeLayout.LayoutParams rp(View v) {
        return (RelativeLayout.LayoutParams) v.getLayoutParams();
    }

    LinearLayout.LayoutParams lp(View v) {
        return (LinearLayout.LayoutParams) v.getLayoutParams();
    }

    public int cp(int cp) {
        float pixel = width * cp / 1440.0f;
        return (int) pixel;
    }
}
