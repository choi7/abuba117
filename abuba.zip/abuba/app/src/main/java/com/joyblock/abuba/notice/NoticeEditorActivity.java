package com.joyblock.abuba.notice;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.TextView;

import com.joyblock.abuba.BaseActivity;
import com.joyblock.abuba.R;

import org.json.JSONObject;

import java.io.IOException;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.RequestBody;

public class NoticeEditorActivity extends BaseActivity {


    RadioGroup rg;
    String checkid = "y", is_reply = "y", seq_user, seq_kindergarden, seq_kindergarden_class, maintitle, intext, files;
    String noticeEditorPush = "http://58.229.208.246/Ububa/insertNotice.do";
    Boolean imageChange = true;
    EditText titleText, inText;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notice_editor);

        titleText = (EditText) findViewById(R.id.titleText);
        inText = (EditText) findViewById(R.id.inText);


        ImageView pictureRegister = (ImageView) findViewById(R.id.pictureRegisterimageView);
        pictureRegister.setVisibility(View.VISIBLE);
        TextView txt = (TextView) findViewById(R.id.comenttextView);
        txt.setVisibility(View.VISIBLE);
        final ImageView replyCheck = (ImageView) findViewById(R.id.replyCheckImage);
        replyCheck.setVisibility(View.VISIBLE);
        replyCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(imageChange) {
                    replyCheck.setImageDrawable(getResources().getDrawable(R.drawable.del));
                    is_reply = "n";
                    imageChange = false;
                } else {
                    replyCheck.setImageDrawable(getResources().getDrawable(R.drawable.ch_off));
                    is_reply = "y";
                    imageChange = true;
                }
            }
        });

        actionbarCustom();



        seq_user = pref.getString("seq_user","없음");
        seq_kindergarden = pref.getString("seq_kindergarden","없음");
//        seq_kindergarden_class = pref.getString("seq_kindergarden_class","없음");
        seq_kindergarden_class = "1";
        files = "";

        System.out.println("sssss");
        System.out.println(seq_user + seq_kindergarden + seq_kindergarden_class);
        System.out.println("sssss");



    }




    public class BuyTask extends AsyncTask<Void, Void, String> {
        OkHttpClient client;
        okhttp3.Request request;
        RequestBody formBody;

        public BuyTask(String seq_user, String seq_kindergarden, String is_reply, String title, String content) {
            client = new OkHttpClient();
            formBody = new FormBody.Builder()
                    .add("seq_user", seq_user)
                    .add("seq_kindergarden", seq_kindergarden)
                    .add("is_reply", is_reply)
//                    .add("seq_kindergarden_class", seq_kindergarden_class)
                    .add("title", title)
                    .add("content", content)
//                    .add("files", files)
//                    .add("cu_num", cu_num + "")
                    .build();

            request = new okhttp3.Request.Builder()
                    .url("http://58.229.208.246/Ububa/insertNotice.do")
                    .post(formBody)
                    .build();

        }


        @Override
        protected String doInBackground(Void... params) {
            try {
                okhttp3.Response response = client.newCall(request).execute();
                if (!response.isSuccessful()) {
                    return null;
                }

                return response.body().string();
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String json) {
            super.onPostExecute(json);
            Log.d("TAG", json);
            try {
                JSONObject jsonResponse = new JSONObject(json);
                System.out.println("반환되는 값 : " + jsonResponse);
                Integer ss = Integer.parseInt(jsonResponse.getString("resultCode"));
                System.out.println(ss);
                if (ss == 200) {
                    String userID = jsonResponse.getString("resultCode");
                    String userPassword = jsonResponse.getString("resultMsg");
                    System.out.println(userID + userPassword);
//                    JSONObject json1 = new JSONObject(jsonResponse.getString("retMap"));
//                    System.out.println(json1);
                    Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
                    NoticeEditorActivity.this.startActivity(intent);
                    finish();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void actionbarCustom() {
        getSupportActionBar().setDisplayShowCustomEnabled(true);
        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(0xff0099ff));
        getSupportActionBar().setDisplayOptions(ActionBar.DISPLAY_SHOW_CUSTOM);
        getSupportActionBar().setCustomView(R.layout.actionbarcustom);
        TextView title = (TextView) findViewById(R.id.titleName);
        title.setText("전체");

        title.setVisibility(View.VISIBLE);
        title.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                System.out.println("반을 선택하세요");

            }

        });


        TextView backText = (TextView) findViewById(R.id.editorTextLeft);
        backText.setVisibility(View.VISIBLE);
        backText.setText("취소");
        backText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder nd = new AlertDialog.Builder(NoticeEditorActivity.this);
                nd.setMessage("작성을 취소하시겠습니까")
                        .setNegativeButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
                                NoticeEditorActivity.this.startActivity(intent);

                                finish();
                            }
                        })
                        .setPositiveButton("취소", null)
                        .create()
                        .show();
            }
        });

        ImageView backImage = (ImageView) findViewById(R.id.backImage);
        backImage.setVisibility(View.GONE);

        TextView textView = (TextView) findViewById(R.id.editorText);
        textView.setVisibility(View.VISIBLE);
        textView.setText("등록");
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder nd = new AlertDialog.Builder(NoticeEditorActivity.this);
                nd.setMessage("등록하시겠습니까")
                        .setNegativeButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                maintitle = titleText.getText().toString();
                                intext = inText.getText().toString();

                                Log.d("타이틀" , maintitle);
                                Log.d("sub타이틀" , intext);


                                BuyTask buyTask = new BuyTask(seq_user,seq_kindergarden,is_reply,maintitle, intext);

                                buyTask.execute();



                            }
                        })
                        .setPositiveButton("취소", null)
                        .create()
                        .show();
            }
        });


        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.parseColor("#0099FF"));
        }
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().setStatusBarColor(Color.parseColor("#FFFFFF"));
        }
    }


    /*
    @SuppressLint("ResourceType")
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.noticeedit, menu);
        return super.onCreateOptionsMenu(menu);
    }


    //액션바 아이템 선택시 실행되는 메소드
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        System.out.println(item);
        System.out.println(item);
        System.out.println(item);
        System.out.println(item);

        switch (item.getItemId()) {
            case R.id.noticeRegister:
                System.out.println("등록하면 해야 될일");
                Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
                NoticeEditorActivity.this.startActivity(intent);
                finish();
                return true;
            default:
                System.out.println(item);
                return super.onOptionsItemSelected(item);
        }

    }
    */


    /*
    //휴대폰 하단 백 버튼 눌렀을때 실행되는 메소드
    @Override
    public void onBackPressed() {
        super.onBackPressed();

        AlertDialog.Builder nd = new AlertDialog.Builder(NoticeEditorActivity.this);
        nd.setMessage("작성을 취소하시겠습니까")
                .setNegativeButton("확인", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
                        NoticeEditorActivity.this.startActivity(intent);

                        finish();
                    }
                })
                .setPositiveButton("취소", null)
                .create()
                .show();

//        Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
//        NoticeEditorActivity.this.startActivity(intent);
//
//        finish();

    }

    */

    /*
    //화면 상단 왼쪽에 있는 백 버튼 눌렀을때 실행되는 메소드
    //백 버튼 활성화는 액션바.setDisplayHomeAsUpEnabled(true);
    @Override
    public boolean onSupportNavigateUp() {

        Toast.makeText(NoticeEditorActivity.this, "뒤로가기 버튼 눌름",Toast.LENGTH_LONG).show();
        Intent intent = new Intent(NoticeEditorActivity.this, NoticeActivity.class);
        NoticeEditorActivity.this.startActivity(intent);
        finish();

        return super.onSupportNavigateUp();
    }
    */

}
